package bot.gui;

public class GuiManager {
    // Este método inicializa la interfaz gráfica de usuario (GUI)
    public void initializeGui() {
        // Lógica para inicializar la GUI
    }

    // Este método puede ser utilizado para actualizar la GUI
    public void updateGui() {
        // Lógica para actualizar la GUI
    }
}