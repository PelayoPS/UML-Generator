package slash_commands;

public enum Code {
    USER, MOD, ADMIN
}
